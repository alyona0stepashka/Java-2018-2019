package enums;

public enum fabricEnum { book, catalogue, Bucklet}
