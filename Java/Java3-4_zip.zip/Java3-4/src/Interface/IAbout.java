package Interface;

public interface IAbout
{
    String talkUrSelf();
}
