package by.belstu.poit.dimakot.student;

public interface Actions {
    void GoWalk();
    void MissLesson();
    void PlayGames();
}
