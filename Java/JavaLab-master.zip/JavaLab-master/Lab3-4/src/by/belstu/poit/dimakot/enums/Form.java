package by.belstu.poit.dimakot.enums;

public enum Form {
    DAY, EVENING, ZAOCH
}
