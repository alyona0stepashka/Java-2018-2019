package by.belstu.poit.dimakot.enums;

public enum Spec {
    POIT, ISIT, POiBMS, DEVI
}
