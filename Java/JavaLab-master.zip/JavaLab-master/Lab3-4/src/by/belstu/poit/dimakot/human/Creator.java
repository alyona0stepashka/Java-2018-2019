package by.belstu.poit.dimakot.human;
import by.belstu.poit.dimakot.potok.Potok;

 public  abstract class Creator {
    public abstract Potok FactoryMethod(String val);
}
